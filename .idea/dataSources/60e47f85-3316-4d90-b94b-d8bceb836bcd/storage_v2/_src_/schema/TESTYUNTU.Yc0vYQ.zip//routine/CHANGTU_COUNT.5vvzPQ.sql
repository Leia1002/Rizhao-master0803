create function changtu_count
return  varchar2
as
v_count number(10,2);
v_result varchar2(256);
begin
   SELECT count(1)into v_count FROM COACH_KSHX_BIOPS WHERE RECORD_UPDATED_TIME >= sysdate - 1/24;
   v_result:='COACH_KSHX_BIOPS:'||to_char(v_count);
   SELECT count(1)  into v_count FROM COACH_KSHX_BUSPLANINFO WHERE RECORD_UPDATED_TIME >= sysdate - 1/24;
   v_result:=v_result ||';'||'COACH_KSHX_BUSPLANINFO:'||to_char(v_count);
   SELECT count(1) into v_count FROM COACH_KSHX_OPVI WHERE RECORD_UPDATED_TIME >= sysdate - 1/24;
   v_result:=v_result ||';'||'COACH_KSHX_OPVI:'||to_char(v_count);
   SELECT count(1)  into v_count FROM  COACH_KSHX_PBDI WHERE RECORD_UPDATED_TIME >= sysdate - 1/24;
   v_result:=v_result ||';'||'COACH_KSHX_PBDI:'||to_char(v_count);
   SELECT count(1) into v_count FROM COACH_KSHX_PDTI WHERE RECORD_UPDATED_TIME >= sysdate - 1/24;
   v_result:=v_result ||';'||'COACH_KSHX_PDTI:'||to_char(v_count);
   SELECT count(1) into v_count FROM COACH_KSHX_PLANOPERATIONINFO WHERE RECORD_UPDATED_TIME >= sysdate - 1/24;
   v_result:=v_result ||';'||'COACH_KSHX_PLANOPERATIONINFO:'||to_char(v_count);
   SELECT count(1) into v_count FROM COACH_KSHX_PRI WHERE RECORD_UPDATED_TIME >= sysdate - 1/24;
   v_result:=v_result ||';'||'COACH_KSHX_PRI:'||to_char(v_count);
   SELECT count(1) into v_count FROM COACH_KSHX_PTC WHERE RECORD_UPDATED_TIME >= sysdate - 1/24;
   v_result:=v_result ||';'||'COACH_KSHX_PTC:'||to_char(v_count);
   SELECT count(1) into v_count FROM COACH_KSHX_PTI WHERE RECORD_UPDATED_TIME >= sysdate - 1/24;
   v_result:=v_result ||';'||'COACH_KSHX_PTI:'||to_char(v_count);
   SELECT count(1) into v_count FROM COACH_KSHX_PVII WHERE RECORD_UPDATED_TIME >= sysdate - 1/24;
   v_result:=v_result ||';'||'COACH_KSHX_PVII:'||to_char(v_count);
  return v_result;
  end;

/

